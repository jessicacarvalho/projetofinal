<?php
	$email = $_POST['email'];
	$senha = $_POST['senha'];

	$con = mysqli_connect("localhost", "root", "", "projeto");
	$query = "select * from cliente
				where email = '$email'
				and senha = '$senha' limit 1" ;
	$consulta = mysqli_query($con, $query);
	$total = mysqli_num_rows($consulta);
		if($total == 0){
			include "index.html";
			echo "E-mail ou senha inválida!";		
		}else{
			while($f = mysqli_fetch_array($consulta)){
				$id = $f['id'];
				session_start();
				$_SESSION['email'] = $email;
				$_SESSION['id'] = $id;
				header("Location: perfil.php");
			}
		}
?>